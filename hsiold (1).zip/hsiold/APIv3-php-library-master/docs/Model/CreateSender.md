# CreateSender

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | From Name to use for the sender | 
**email** | **string** | From email to use for the sender. A verification email will be sent to this address. | 
**ips** | [**\SendinBlue\Client\Model\CreateSenderIps[]**](CreateSenderIps.md) | Mandatory in case of dedicated IP, IPs to associate to the sender | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


