# GetContacts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**contacts** | **object[]** |  | 
**count** | **int** | Number of contacts | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


