# GetDeviceBrowserStats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clickers** | **int** | Number of total clicks for the campaign using the particular browser | 
**uniqueClicks** | **int** | Number of unique clicks for the campaign using the particular browser | 
**viewed** | **int** | Number of openings for the campaign using the particular browser | 
**uniqueViews** | **int** | Number of unique openings for the campaign using the particular browser | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


