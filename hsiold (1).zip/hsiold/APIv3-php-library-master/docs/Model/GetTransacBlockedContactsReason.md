# GetTransacBlockedContactsReason

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **string** | Reason code for blocking / unsubscribing (This code is safe for comparison) | [optional] 
**message** | **string** | Reason for blocking / unsubscribing (This string is not safe for comparison) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


