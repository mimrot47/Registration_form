# SendEmailAttachment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**content** | **string** | Base64 encoded chunk data of the attachment generated on the fly | 
**name** | **string** | Required for content. Name of the attachment | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


